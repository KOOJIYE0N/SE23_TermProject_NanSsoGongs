
import './App.css';
import Login from './Login';

function App() {
  return (
    <div>
      <Login/>
    </div>
  );
}

export default App;
